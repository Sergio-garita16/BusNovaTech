
package com.busnovaterch.busnovatech;

import javax.swing.JOptionPane;


public class BusNovaTech {

    public static void main(String[] args) {
        // Módulo 1.0: Configuración
        Config configuracion = new Config();
        configuracion.iniciar();
 
        // Módulo 1.1: cargar tiquetes pendientes (si existen) desde tiquetes.json
        GestionTiquetes gestionTiquetes = new GestionTiquetes();
        gestionTiquetes.cargarTiquetes(configuracion.getBuses());
 
        // Inicio de sesión usando los usuarios cargados desde config.json
        Login login = new Login(configuracion.getUsuarios());
        boolean autenticado = login.iniciar();
        if (!autenticado) {
            return;
        }
 
        // Módulo 1.1: menú de creación de tiquetes (con opción para ver el estado de las colas)
        String terminal = configuracion.getNombreTerminal();
        String[] opciones = {"Crear tiquete", "Abordar tiquete", "Ver estado de colas", "Ver atendidos", "Salir"};
        int seleccion;
        do {
            seleccion = JOptionPane.showOptionDialog(null, "¿Qué desea hacer?", "Menú",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
 
            if (seleccion == 0) {
                gestionTiquetes.crearTiquete(configuracion.getBuses(), terminal);
            } else if (seleccion == 1) {
                gestionTiquetes.abordarTiquete(configuracion.getBuses(), terminal);
            } else if (seleccion == 2) {
                gestionTiquetes.mostrarEstadoColas(configuracion.getBuses());
            } else if (seleccion == 3) {
                gestionTiquetes.mostrarAtendidos();
            }
        } while (seleccion != -1 && seleccion != 4);
    }
}