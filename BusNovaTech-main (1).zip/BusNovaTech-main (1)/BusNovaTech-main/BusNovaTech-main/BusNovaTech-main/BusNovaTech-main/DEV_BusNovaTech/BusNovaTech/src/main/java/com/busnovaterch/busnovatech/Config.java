/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busnovaterch.busnovatech;

import javax.swing.JOptionPane;
import java.io.*;
import java.nio.charset.StandardCharsets;


/**
 *
 * @author XPC
 */
public class Config {
  private static final String ARCHIVO = "config.json";
 
    private String nombreTerminal;
    private ListaBuses buses = new ListaBuses();
    private ListaUsuarios usuarios = new ListaUsuarios();
 
    public String getNombreTerminal() { return nombreTerminal; }
    public ListaBuses getBuses() { return buses; }
    public ListaUsuarios getUsuarios() { return usuarios; }
 
    public void iniciar() {
        File archivo = new File(ARCHIVO);
        if (archivo.exists()) {
            try {
                cargarDesdeJSON();
                return;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "config.json dañado o incompleto. Se configurará de nuevo.");
            }
        }
        nombreTerminal = pedirTexto("Nombre de la terminal:");
        crearBuses(pedirCantidadBuses());
        pedirUsuarios();
        guardarEnJSON();
        JOptionPane.showMessageDialog(null, "Configuración guardada en " + ARCHIVO);
    }
 
    //  Asistente de configuración 
 
    private String pedirTexto(String mensaje) {
        String valor;
        do {
            valor = JOptionPane.showInputDialog(null, mensaje);
            if (valor == null) salirSiConfirma();
        } while (valor == null || valor.trim().isEmpty());
        return valor.trim();
    }
 
    private int pedirCantidadBuses() {
        while (true) {
            String txt = JOptionPane.showInputDialog(null,
                    "Cantidad total de buses (mínimo 2: incluye 1 preferencial y 1 directo):");
            if (txt == null) { salirSiConfirma(); continue; }
            try {
                int n = Integer.parseInt(txt.trim());
                if (n >= 2) return n;
            } catch (NumberFormatException ignored) { }
            JOptionPane.showMessageDialog(null, "Ingrese un entero mayor o igual a 2.");
        }
    }
 
    private void crearBuses(int cantidad) {
        buses = new ListaBuses();
        for (int i = 1; i <= cantidad; i++) {
            char tipo = (i == 1) ? 'P' : (i == 2) ? 'D' : 'N';
            buses.insertar(new NodoBus(i, tipo));
        }
    }
 
    private void pedirUsuarios() {
        usuarios = new ListaUsuarios();
        do {
            String nombre = pedirTexto("Nombre completo del usuario:");
            String user;
            do {
                user = pedirTexto("Usuario (login):");
                if (usuarios.buscar(user) != null) {
                    JOptionPane.showMessageDialog(null, "Ese usuario ya existe.");
                    user = null;
                }
            } while (user == null);
            String clave = pedirTexto("Contraseña:");
            usuarios.insertar(new NodoUsuario(nombre, user, clave));
        } while (usuarios.getTamano() < 1
                || JOptionPane.showConfirmDialog(null, "¿Registrar otro usuario?", "Usuarios",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION);
    }
 
    private void salirSiConfirma() {
        if (JOptionPane.showConfirmDialog(null, "La configuración es obligatoria. ¿Salir?", "Salir",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
 
    //  Persistencia en config.json 
 
    private void guardarEnJSON() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"terminal\": \"").append(Jsonutils.escapar(nombreTerminal)).append("\",\n");
        sb.append("  \"buses\": [\n");
        for (NodoBus b = buses.getFrente(); b != null; b = b.getSiguiente()) {
            sb.append("    {\"id\": ").append(b.getIdBus()).append(", \"tipo\": \"")
              .append(b.getTipoBus()).append("\"}").append(b.getSiguiente() != null ? ",\n" : "\n");
        }
        sb.append("  ],\n  \"usuarios\": [\n");
        for (NodoUsuario u = usuarios.getFrente(); u != null; u = u.getSiguiente()) {
            sb.append("    {\"nombre\": \"").append(Jsonutils.escapar(u.getNombre()))
              .append("\", \"usuario\": \"").append(Jsonutils.escapar(u.getUsuario()))
              .append("\", \"clave\": \"").append(Jsonutils.escapar(u.getClave())).append("\"}")
              .append(u.getSiguiente() != null ? ",\n" : "\n");
        }
        sb.append("  ]\n}\n");
 
        try (Writer w = new OutputStreamWriter(new FileOutputStream(ARCHIVO), StandardCharsets.UTF_8)) {
            w.write(sb.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar config.json: " + e.getMessage());
        }
    }
 
    private void cargarDesdeJSON() throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(ARCHIVO), StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = br.readLine()) != null) sb.append(linea).append('\n');
        }
        String json = sb.toString();
 
        nombreTerminal = Jsonutils.valorTexto(json, "terminal");
 
        buses = new ListaBuses();
        for (String obj : Jsonutils.separarObjetos(Jsonutils.bloqueArreglo(json, "buses"))) {
            if (obj.trim().isEmpty()) continue;
            buses.insertar(new NodoBus(Integer.parseInt(Jsonutils.valorNumerico(obj, "id")), Jsonutils.valorTexto(obj, "tipo").charAt(0)));
        }
 
        usuarios = new ListaUsuarios();
        for (String obj : Jsonutils.separarObjetos(Jsonutils.bloqueArreglo(json, "usuarios"))) {
            if (obj.trim().isEmpty()) continue;
            usuarios.insertar(new NodoUsuario(Jsonutils.valorTexto(obj, "nombre"), Jsonutils.valorTexto(obj, "usuario"), Jsonutils.valorTexto(obj, "clave")));
        }
 
        if (nombreTerminal == null || buses.getTamano() == 0 || usuarios.getTamano() == 0
                || buses.buscarPorTipo('P') == null || buses.buscarPorTipo('D') == null) {
            throw new IOException("Datos incompletos");
        }
    }   
}
