/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.busnovaterch.busnovatech;

import javax.swing.JOptionPane;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author XPC
 */
public class GestionTiquetes {


private static final String ARCHIVO = "tiquetes.json";
    private static final DateTimeFormatter FORMATO_HORA = DateTimeFormatter.ofPattern("HH:mm:ss");
 
    /** Solicita los datos de un cliente, crea el tiquete y lo encola. */
    public void crearTiquete(ListaBuses buses, String terminal) {
        String nombre = pedirTexto("Nombre del cliente:");
        String id = pedirTexto("Identificación del cliente:");
        int edad = pedirEdad();
        String moneda = pedirMoneda();
 
        NodoBus busDestino = elegirBus(buses);
        if (busDestino == null) {
            JOptionPane.showMessageDialog(null, "No hay un bus disponible para ese tipo.");
            return;
        }
 
        boolean colaEstabaVacia = busDestino.getFilaClientes().estaVacia();
 
        String horaCompra = LocalTime.now().format(FORMATO_HORA);
        NodoTiquete tiquete = new NodoTiquete(nombre, id, edad, moneda, horaCompra, busDestino.getTipoBus());
        tiquete.setTerminalCompra(terminal);
        busDestino.getFilaClientes().insertarPorPrioridad(tiquete);
 
        guardarTiquetes(buses);
 
        JOptionPane.showMessageDialog(null,
                "Tiquete creado para " + nombre + ".\nAsignado al bus #" + busDestino.getIdBus()
                        + " (" + describirTipo(busDestino.getTipoBus()) + ").",
                "Tiquete registrado", JOptionPane.INFORMATION_MESSAGE);
 
        
        if (colaEstabaVacia && !busDestino.isInspectorOcupado()) {
            atenderTiquete(busDestino, buses, terminal);
        }
    }
 
    private String pedirTexto(String mensaje) {
        String valor;
        do {
            valor = JOptionPane.showInputDialog(null, mensaje);
            if (valor == null) return "";
        } while (valor.trim().isEmpty());
        return valor.trim();
    }
 
    private int pedirEdad() {
        while (true) {
            String txt = JOptionPane.showInputDialog(null, "Edad del cliente:");
            if (txt == null) return 0;
            try {
                int edad = Integer.parseInt(txt.trim());
                if (edad >= 0) return edad;
            } catch (NumberFormatException ignored) { }
            JOptionPane.showMessageDialog(null, "Ingrese una edad válida.");
        }
    }
 
    private String pedirMoneda() {
        String[] opciones = {"Dólares", "Colones"};
        int sel = JOptionPane.showOptionDialog(null, "Moneda de la cuenta:", "Moneda",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        return (sel == 1) ? "Colones" : "Dólares";
    }
 
    private NodoBus elegirBus(ListaBuses buses) {
        String[] opciones = {"Preferencial", "Directo", "Normal"};
        int sel = JOptionPane.showOptionDialog(null, "Tipo de tiquete:", "Tipo de bus",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        switch (sel) {
            case 0: return buses.buscarPorTipo('P');
            case 1: return buses.buscarPorTipo('D');
            case 2: return buses.buscarBusNormalConMenosClientes();
            default: return null;
        }
    }
 
    private String describirTipo(char tipo) {
        switch (Character.toUpperCase(tipo)) {
            case 'P': return "Preferencial";
            case 'D': return "Directo";
            default: return "Normal";
        }
    }
 
    /** Muestra cuántas personas hay en la cola de cada bus (útil para verificar el balanceo de colas). */
    public void mostrarEstadoColas(ListaBuses buses) {
        StringBuilder texto = new StringBuilder("Estado actual de las colas:\n\n");
        for (NodoBus b = buses.getFrente(); b != null; b = b.getSiguiente()) {
            texto.append("Bus #").append(b.getIdBus())
                 .append(" (").append(describirTipo(b.getTipoBus())).append("): ")
                 .append(b.getFilaClientes().getTamaño()).append(" persona(s) en fila")
                 .append(b.isInspectorOcupado() ? " — inspector ocupado\n" : " — inspector libre\n");
        }
        JOptionPane.showMessageDialog(null, texto.toString(), "Estado de colas", JOptionPane.INFORMATION_MESSAGE);
    }

    

    private static final String ARCHIVO_ATENDIDOS = "atendidos.json";

    /** Menú para elegir manualmente cuál bus debe abordar a su siguiente cliente en fila. */
    public void abordarTiquete(ListaBuses buses, String terminal) {
        java.util.ArrayList<NodoBus> disponibles = new java.util.ArrayList<>();
        for (NodoBus b = buses.getFrente(); b != null; b = b.getSiguiente()) {
            if (!b.isInspectorOcupado() && !b.getFilaClientes().estaVacia()) {
                disponibles.add(b);
            }
        }
        if (disponibles.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "No hay buses con clientes en espera y el inspector libre en este momento.");
            return;
        }

        String[] opciones = new String[disponibles.size()];
        for (int i = 0; i < disponibles.size(); i++) {
            NodoBus b = disponibles.get(i);
            opciones[i] = "Bus #" + b.getIdBus() + " (" + describirTipo(b.getTipoBus()) + ") — "
                    + b.getFilaClientes().getTamaño() + " en fila";
        }
        int sel = JOptionPane.showOptionDialog(null, "¿Cuál bus va a abordar al siguiente cliente?",
                "Abordar tiquete", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, opciones, opciones[0]);
        if (sel == -1) return;

        atenderTiquete(disponibles.get(sel), buses, terminal);
    }

    /**
     * Atiende (aborda) al cliente que está de primero en la fila de un bus.
     * Cobra el servicio elegido; si el cliente se niega a pagar, se saca de
     * la fila (debe generar un nuevo tiquete). Si paga, se marca como
     * "Atendido", se registra la hora de abordaje y se guarda en atendidos.json.
     */
    private void atenderTiquete(NodoBus bus, ListaBuses buses, String terminal) {
        if (bus.isInspectorOcupado()) {
            JOptionPane.showMessageDialog(null, "El inspector de este bus ya está atendiendo a alguien.");
            return;
        }
        if (bus.getFilaClientes().estaVacia()) {
            JOptionPane.showMessageDialog(null, "No hay tiquetes en espera para este bus.");
            return;
        }

        bus.setInspectorOcupado(true);
        NodoTiquete tiquete = bus.getFilaClientes().desencolar();

        try {
            String servicio = pedirServicio();
            if (servicio == null) {
                // El inspector canceló la atención; el cliente vuelve al frente de la fila.
                reinsertarAlFrente(bus, tiquete);
                return;
            }

            double libras = 0;
            if (servicio.equals("CARGA")) {
                libras = pedirLibras();
            }
            double montoUSD = calcularMonto(servicio, libras);

            double montoMostrado = montoUSD;
            String monedaMostrada = "USD";
            if (tiquete.getMonedaCuenta().equalsIgnoreCase("Colones")) {
                double tipoCambio = Bancocentral.obtenerTipoCambioVentaDolar();
                if (tipoCambio > 0) {
                    montoMostrado = montoUSD * tipoCambio;
                    monedaMostrada = "CRC";
                }
            }

            String mensajeCobro = String.format(
                    "Servicio: %s%s\nMonto a cobrar: %.2f %s\n\n¿El cliente acepta pagar?",
                    servicio, servicio.equals("CARGA") ? " (" + libras + " lb)" : "",
                    montoMostrado, monedaMostrada);

            int pago = JOptionPane.showConfirmDialog(null, mensajeCobro, "Cobro de servicio",
                    JOptionPane.YES_NO_OPTION);

            if (pago != JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(null,
                        tiquete.getNombre() + " no aceptó pagar y fue sacado de la fila.\n"
                        + "Debe generar un nuevo tiquete para volver a intentarlo.");
                guardarTiquetes(buses);
                return;
            }

            String horaAbordaje = LocalTime.now().format(FORMATO_HORA);
            tiquete.setServicio(servicio);
            tiquete.setLibras(libras);
            tiquete.setMontoCobrado(montoUSD);
            tiquete.setEstado("ATENDIDO");
            tiquete.setHoraAbordaje(horaAbordaje);
            if (tiquete.getTerminalCompra() == null || tiquete.getTerminalCompra().isEmpty()) {
                tiquete.setTerminalCompra(terminal);
            }

            guardarAtendido(tiquete, bus, terminal);
            guardarTiquetes(buses);

            JOptionPane.showMessageDialog(null,
                    tiquete.getNombre() + " abordó el bus #" + bus.getIdBus()
                    + " a las " + horaAbordaje + ".\nQuedó registrado como Atendido.",
                    "Abordaje completado", JOptionPane.INFORMATION_MESSAGE);

        } finally {
            bus.setInspectorOcupado(false);
        }
    }

    private void reinsertarAlFrente(NodoBus bus, NodoTiquete tiquete) {
        // Vuelve a poner al cliente exactamente donde estaba (respeta prioridad).
        bus.getFilaClientes().insertarPorPrioridad(tiquete);
    }

    private String pedirServicio() {
        String[] opciones = {"Regular", "VIP", "Ejecutivo", "Carga"};
        int sel = JOptionPane.showOptionDialog(null, "Tipo de servicio del cliente:", "Servicio",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        switch (sel) {
            case 0: return "REGULAR";
            case 1: return "VIP";
            case 2: return "EJECUTIVO";
            case 3: return "CARGA";
            default: return null;
        }
    }

    private double pedirLibras() {
        while (true) {
            String txt = JOptionPane.showInputDialog(null, "Libras de carga a transportar:");
            if (txt == null) return 0;
            try {
                double libras = Double.parseDouble(txt.trim().replace(",", "."));
                if (libras >= 0) return libras;
            } catch (NumberFormatException ignored) { }
            JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
        }
    }

  
    private double calcularMonto(String servicio, double libras) {
        double base = 20;
        switch (servicio) {
            case "VIP": return base + 100;
            case "EJECUTIVO": return base + 1000;
            case "CARGA": return base + (10 * libras);
            default: return base; // REGULAR
        }
    }

    
    private void guardarAtendido(NodoTiquete t, NodoBus bus, String terminal) {
        java.util.List<String> objetosExistentes = new java.util.ArrayList<>();
        File archivo = new File(ARCHIVO_ATENDIDOS);
        if (archivo.exists()) {
            try {
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(new FileInputStream(ARCHIVO_ATENDIDOS), StandardCharsets.UTF_8))) {
                    String linea;
                    while ((linea = br.readLine()) != null) sb.append(linea).append('\n');
                }
                for (String obj : Jsonutils.separarObjetos(Jsonutils.bloqueArreglo(sb.toString(), "atendidos"))) {
                    if (!obj.trim().isEmpty()) objetosExistentes.add(obj);
                }
            } catch (Exception e) {
                // Si el archivo está dañado, se reconstruye solo con el nuevo registro.
            }
        }

        StringBuilder nuevo = new StringBuilder();
        nuevo.append("{\"nombre\": \"").append(Jsonutils.escapar(t.getNombre()))
             .append("\", \"id\": \"").append(Jsonutils.escapar(t.getId()))
             .append("\", \"edad\": ").append(t.getEdad())
             .append(", \"monedaCuenta\": \"").append(Jsonutils.escapar(t.getMonedaCuenta()))
             .append("\", \"horaCompra\": \"").append(Jsonutils.escapar(t.getHoraCompra()))
             .append("\", \"horaAbordaje\": \"").append(Jsonutils.escapar(t.getHoraAbordaje()))
             .append("\", \"servicio\": \"").append(Jsonutils.escapar(t.getService()))
             .append("\", \"libras\": ").append(t.getLibras())
             .append(", \"montoCobradoUSD\": ").append(t.getMontoCobrado())
             .append(", \"tipoBus\": \"").append(t.getTipoBus())
             .append("\", \"idBus\": ").append(bus.getIdBus())
             .append(", \"terminal\": \"").append(Jsonutils.escapar(terminal)).append("\"}");
        objetosExistentes.add(nuevo.toString());

        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"atendidos\": [\n");
        for (int i = 0; i < objetosExistentes.size(); i++) {
            sb.append("    ").append(objetosExistentes.get(i));
            sb.append(i < objetosExistentes.size() - 1 ? ",\n" : "\n");
        }
        sb.append("  ]\n}\n");

        try (Writer w = new OutputStreamWriter(new FileOutputStream(ARCHIVO_ATENDIDOS), StandardCharsets.UTF_8)) {
            w.write(sb.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar atendidos.json: " + e.getMessage());
        }
    }

    /** Muestra en pantalla el historial de clientes atendidos: bus abordado y terminal de compra. */
    public void mostrarAtendidos() {
        File archivo = new File(ARCHIVO_ATENDIDOS);
        if (!archivo.exists()) {
            JOptionPane.showMessageDialog(null, "Todavía no hay clientes atendidos.");
            return;
        }
        try {
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(new FileInputStream(ARCHIVO_ATENDIDOS), StandardCharsets.UTF_8))) {
                String linea;
                while ((linea = br.readLine()) != null) sb.append(linea).append('\n');
            }
            String json = sb.toString();
            String[] objetos = Jsonutils.separarObjetos(Jsonutils.bloqueArreglo(json, "atendidos"));

            if (objetos.length == 0) {
                JOptionPane.showMessageDialog(null, "Todavía no hay clientes atendidos.");
                return;
            }

            StringBuilder texto = new StringBuilder("Clientes atendidos:\n\n");
            for (String obj : objetos) {
                if (obj.trim().isEmpty()) continue;
                texto.append("• ").append(Jsonutils.valorTexto(obj, "nombre"))
                     .append(" — Servicio: ").append(Jsonutils.valorTexto(obj, "servicio"))
                     .append(" — Bus #").append(Jsonutils.valorNumerico(obj, "idBus"))
                     .append(" — Terminal: ").append(Jsonutils.valorTexto(obj, "terminal"))
                     .append(" — Abordó: ").append(Jsonutils.valorTexto(obj, "horaAbordaje"))
                     .append("\n");
            }
            JOptionPane.showMessageDialog(null, texto.toString(), "Historial de atendidos",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "atendidos.json está dañado.");
        }
    }

  
 
    private void guardarTiquetes(ListaBuses buses) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"tiquetes\": [\n");
        boolean primero = true;
        for (NodoBus b = buses.getFrente(); b != null; b = b.getSiguiente()) {
            for (NodoTiquete t = b.getFilaClientes().getFrente(); t != null; t = t.getSiguiente()) {
                if (!primero) sb.append(",\n");
                sb.append("    {\"nombre\": \"").append(Jsonutils.escapar(t.getNombre()))
                  .append("\", \"id\": \"").append(Jsonutils.escapar(t.getId()))
                  .append("\", \"edad\": ").append(t.getEdad())
                  .append(", \"monedaCuenta\": \"").append(Jsonutils.escapar(t.getMonedaCuenta()))
                  .append("\", \"horaCompra\": \"").append(Jsonutils.escapar(t.getHoraCompra()))
                  .append("\", \"horaAbordaje\": \"").append(Jsonutils.escapar(t.getHoraAbordaje()))
                  .append("\", \"servicio\": \"").append(Jsonutils.escapar(t.getService()))
                  .append("\", \"tipoBus\": \"").append(t.getTipoBus())
                  .append("\", \"idBus\": ").append(b.getIdBus())
                  .append(", \"terminal\": \"").append(Jsonutils.escapar(t.getTerminalCompra())).append("\"}");
                primero = false;
            }
        }
        sb.append("\n  ]\n}\n");
 
        try (Writer w = new OutputStreamWriter(new FileOutputStream(ARCHIVO), StandardCharsets.UTF_8)) {
            w.write(sb.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar tiquetes.json: " + e.getMessage());
        }
    }
 
    /** Carga los tiquetes pendientes desde tiquetes.json (si existe) al iniciar el sistema. */
    public void cargarTiquetes(ListaBuses buses) {
        File archivo = new File(ARCHIVO);
        if (!archivo.exists()) return;
 
        try {
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(new FileInputStream(ARCHIVO), StandardCharsets.UTF_8))) {
                String linea;
                while ((linea = br.readLine()) != null) sb.append(linea).append('\n');
            }
            String json = sb.toString();
 
            for (String obj : Jsonutils.separarObjetos(Jsonutils.bloqueArreglo(json, "tiquetes"))) {
                if (obj.trim().isEmpty()) continue;
 
                String nombre = Jsonutils.valorTexto(obj, "nombre");
                String id = Jsonutils.valorTexto(obj, "id");
                int edad = Integer.parseInt(Jsonutils.valorNumerico(obj, "edad"));
                String moneda = Jsonutils.valorTexto(obj, "monedaCuenta");
                String horaCompra = Jsonutils.valorTexto(obj, "horaCompra");
                String horaAbordaje = Jsonutils.valorTexto(obj, "horaAbordaje");
                String servicio = Jsonutils.valorTexto(obj, "servicio");
                char tipoBus = Jsonutils.valorTexto(obj, "tipoBus").charAt(0);
                int idBus = Integer.parseInt(Jsonutils.valorNumerico(obj, "idBus"));
                String terminal = Jsonutils.valorTexto(obj, "terminal");
 
                NodoBus bus = buses.buscarPorId(idBus);
                if (bus == null) continue;
 
                NodoTiquete t = new NodoTiquete(nombre, id, edad, moneda, horaCompra, tipoBus);
                t.setHoraAbordaje(horaAbordaje);
                t.setServicio(servicio);
                t.setTerminalCompra(terminal == null ? "" : terminal);
                bus.getFilaClientes().insertarPorPrioridad(t);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "tiquetes.json está dañado, se ignoraron los registros pendientes.");
        }
    }    
}