
package com.busnovaterch.busnovatech;
import javax.swing.JOptionPane;


public class Login {

    private ListaUsuarios usuarios;
 
    public Login(ListaUsuarios usuarios) {
        this.usuarios = usuarios;
    }
 
    public boolean iniciar() {
        int intentos = 3;
        while (intentos > 0) {
            String usuario = JOptionPane.showInputDialog(null,
                    "Ingrese su usuario:",
                    "Inicio de Sesión",
                    JOptionPane.PLAIN_MESSAGE);
            if (usuario == null) {
                JOptionPane.showMessageDialog(null, "Inicio de sesión cancelado.");
                return false;
            }
            String contrasena = JOptionPane.showInputDialog(null,
                    "Ingrese su contraseña:",
                    "Inicio de Sesión",
                    JOptionPane.PLAIN_MESSAGE);
            if (contrasena == null) {
                JOptionPane.showMessageDialog(null, "Inicio de sesión cancelado.");
                return false;
            }
 
            if (autenticar(usuario.trim(), contrasena.trim())) {
                JOptionPane.showMessageDialog(null,
                        "¡Bienvenido, " + usuario + "!",
                        "Acceso Concedido",
                        JOptionPane.INFORMATION_MESSAGE);
                return true;
            } else {
                intentos--;
                if (intentos > 0) {
                    JOptionPane.showMessageDialog(null,
                            "Usuario o contraseña incorrectos.\nIntentos restantes: " + intentos,
                            "Error",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Demasiados intentos fallidos. Acceso bloqueado.",
                            "Bloqueado",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        return false;
    }
 
    private boolean autenticar(String usuario, String contrasena) {
        NodoUsuario encontrado = usuarios.buscar(usuario);
        return encontrado != null && encontrado.getClave().equals(contrasena);
    }
}